import 'particles.js/particles';
const particlesJS = window.particlesJS;

particlesJS.load('bg-home', 'json/particlesjs-config.json', function() {
    console.log('callback - particles-js config loaded');
  });