@extends('layout')
@section('title', 'Projects - Kevin Ceferino')
@section('content')
    <section id="bg-home">
        <div class="home-title">
            <h1>Hi <i class="fa-solid fa-rocket"></i></h1>
            <h1>I'm Projects</h1>
            <h2>Fullstack Developer</h2>
        </div>
    </section>
@endsection
