
<?php $__env->startSection('title', 'Inicio - Kevin Ceferino'); ?>
<?php $__env->startSection('content'); ?>
    <section id="bg-home">
        <div class="home-title">
            <h1>Hi <i class="fa-solid fa-rocket"></i></h1>
            <h1>I'm Projects</h1>
            <h2>Fullstack Developer</h2>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Portafolio\resources\views/pages/projects.blade.php ENDPATH**/ ?>