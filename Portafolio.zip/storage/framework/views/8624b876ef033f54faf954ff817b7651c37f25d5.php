<div class="sidebar">
    <ul class="nav-menu">
        <li class="nav-item"><a href="<?php echo e(route('home')); ?>" class="nav-item-link">About</a></li>
        <li class="nav-item"><a href="<?php echo e(route('skills')); ?>" class="nav-item-link">Skills</a></li>
        <li class="nav-item"><a href="<?php echo e(route('projects')); ?>" class="nav-item-link">Projects</a></li>
        <li class="nav-item"><a href="/" class="nav-item-link">Blog</a></li>
        <li class="nav-item"><a href="<?php echo e(route('contact')); ?>" class="nav-item-link">Contact</a></li>
    </ul>
</div>
<?php /**PATH C:\laragon\www\Portafolio\resources\views/layout/navbar.blade.php ENDPATH**/ ?>