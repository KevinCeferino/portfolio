<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
    <title><?php echo $__env->yieldContent('title', 'Index'); ?></title>
    <script defer src="<?php echo e(asset('js/app.js')); ?>"></script>
    <script src="https://kit.fontawesome.com/261ff6c1d4.js" crossorigin="anonymous"></script>
    <?php echo $__env->yieldContent('head'); ?>
    
</head>
<body>
    <?php echo $__env->make('layout.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <main>
        <?php echo $__env->yieldContent('content'); ?>
    </main>
</body>
</html><?php /**PATH C:\laragon\www\Portafolio\resources\views/layout.blade.php ENDPATH**/ ?>